from pyscp.crawler import WikidotConnector, Snapshot, Page, use_default_logging
